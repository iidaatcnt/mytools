"""
Tests for the eliot package.
"""
